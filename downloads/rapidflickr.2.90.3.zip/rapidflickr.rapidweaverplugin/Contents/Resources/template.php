<!-- Force Transitional -->

<u>  </u>

<!-- style sheets... Tidy will move them to the proper spot -->
<link rel='stylesheet' type='text/css' href='__FILES__/stylesDrop.css' />

<link rel='stylesheet' type='text/css' media='screen' href='__FILES__/lightbox.css' />

<?php
  
  error_reporting(E_ERROR); 


// Need to test their existance in case a RF is being included twice!


if (!function_exists('rwDefaultOutput')) {
	
	//**********************************************************
	// Helper Functions below here
	//
	//
	//**********************************************************
	function rwDefaultOutput($href,$picUrl,$title,$showTitle,$lightbox,$lightboxUrl)
	{
		global $filesdir;
		global $columns;
		$columnWidth=100/$columns;
		$ret= "
<td align='center'
valign='top' width='$columnWidth%'>

<div class='thumbnail-frame' style='position:static;'>
";	
		
		if ($lightbox==1)
			$ret .= "<a href='$lightboxUrl' rel='lightbox'>";
		else if ($lightbox==2)
			$ret .= "\n<a href='$lightboxUrl' \nrel='lightbox[flickr]' \ntitle=\"&lt;a href='$href'&gt;$title&lt;/a&gt;\">";
		else
			$ret .= "<a href='$href'>";
		
		$ret .= "<img  alt='$title' ".
			"src='" . $picUrl . "'/>";
		$ret .= "</a>";
		if($showTitle) {
			if ($lightbox) {
				$lbPrefix="<a href='$href'>";
				$lbPostfix="</a>";
			} else {
				$lbPrefix="";
				$lbPostfix="";
			}
			$ret .= "</div><p class='thumbnail-caption'> $lbPrefix $title $lbPostfix</p></td>\n";
		} else {
			if ($lightbox) {
				$ret .= "</div><a href='$href'> <img src='$filesdir/info_icon.gif' height='15' alt='info icon' align='right' /> </a></td>";
				
			}
		}
		
		return $ret;
	}
	
}

if (!function_exists('dropShadowOutput')) {
	function dropShadowOutput($href,$picUrl,$title,$showTitle,$lightbox,$lightboxUrl)
	{
		
		global $filesdir;
		global $columns;
		$columnWidth=100/$columns;
		global $columns;
		$ret= "
<td align='center'
valign='top' width='$columnWidth%' >

<div class='shadow'>
";
		
		if ($lightbox==1)
			$ret .= "<a href='$lightboxUrl' rel='lightbox'>";
		else if ($lightbox==2)
			$ret .= "\n<a href='$lightboxUrl' \nrel='lightbox[flickr]' \ntitle=\"&lt;a href='$href'&gt;$title&lt;/a&gt;\">";
		else
			$ret .= "<a href='$href'>";
		
		$ret .= "<img  alt='$title' ".
			"src='" . $picUrl . "' style='border-style:none;' />";
		$ret .= "</a>
<div class='topleft'></div>
<div class='topright'></div><div class='bottomleft'></div>
<div class='bottomright'></div>
</div>
$infoGraphic </td>";
		
		
		
		
		return $ret;
	}
	
}

if (!function_exists('dropShadowTitle')) {
	function dropShadowTitle($href,$picUrl,$title,$showTitle,$lightbox,$lightboxUrl)
	{
		global $filesdir;
		
        $ret="<td>\n";
		if($showTitle) {
			if ($lightbox) {
				$lbPrefix="<a href='$href'>";
				$lbPostfix="</a>";
			} else {
				$lbPrefix="";
				$lbPostfix="";
			}
			$ret .= "<p class='thumbnail-caption'> $lbPrefix $title $lbPostfix</p></td>\n";
		} else {
			if ($lightbox) {
				$ret .= "<a href='$href'> <img src='$filesdir/info_icon.gif'  height='15' alt='info icon' style='float:right;border-style:none;bottom:0;' /> </a>";
				
			}
		}
		
		$ret.="</td>\n";
		return $ret;
	}
}



//__LIGHTBOXV1__ 
//__LIGHTBOXV1__ echo "<link rel='stylesheet' type='text/css' href='__FILES__/stylesDrop.css' /><script type='text/javascript'> var loadingImage = '__FILES__/loading.gif'; </script><script type='text/javascript' src='__FILES__/lightbox.js'></script> ";



//__LIGHTBOXV2_OLD__ 

//__LIGHTBOXV2_OLD__  echo '       <script type="text/javascript"> '  ."\n";
//__LIGHTBOXV2_OLD__ echo '//<![CDATA[' ."\n";
//__LIGHTBOXV2_OLD__ echo 'var fileLoadingImage = "__FILES__/loading2.gif";var fileBottomNavCloseImage="__FILES__/closelabel.gif"; ' ."\n";
//__LIGHTBOXV2_OLD__ echo '//]]>' ."\n";
//__LIGHTBOXV2_OLD__ echo "</script><script type='text/javascript' "."\n";
//__LIGHTBOXV2_OLD__ echo "src='__FILES__/prototype.js'>"."\n";
//__LIGHTBOXV2_OLD__ echo "</script> <script type='text/javascript'"."\n";
//__LIGHTBOXV2_OLD__ echo "src='__FILES__/scriptaculous.js?load=effects'>"."\n";
//__LIGHTBOXV2_OLD__ echo '</script> <script type="text/javascript" '."\n";
//__LIGHTBOXV2_OLD__ echo 'src="__FILES__/lightbox2.js">'."\n";
//__LIGHTBOXV2_OLD__ echo '</script>'."\n";


//__LIGHTBOXV2__ echo "<script type='text/javascript' src='__FILES__/mootools.rapidflickr.js'></script><script type='text/javascript' src='__FILES__/slimbox.js'></script><link rel='stylesheet' href='__FILES__/slimbox.css' type='text/css' media='screen' />";

// Template file for live updates of RapidFlickr

$filesdir="__FILES__";

require_once("$filesdir/phpFlickr.php");


// Create new phpFlickr object & set vars as appropriate

__CREATESESSION__
__SHAREDSECRET__
//__TOKEN__
$nsid="__NSID__";
$columns="__COLUMNS__";
$size="__SIZE__";
$lightbox="__LIGHTBOX__";
$lightboxSize="__LIGHTBOXSIZE__";
$showTitles="__SHOWTITLES__";
$photos=__PHOTOS__; // This one is the exception... 
$outputStyle="__OUTPUTSTYLE__";

if($outputStyle=="DropShadow")
  $dropShadow="1";

$i = 0;



//if ($lightbox)
//echo "<link rel='stylesheet' type='text/css' media='screen' href='$filesdir/lightbox.css' /><link rel='stylesheet' type='text/css' href='$filesdir/stylesDrop.css' /><script type='text/javascript'> var loadingImage = '$filesdir/loading.gif'; </script><script type='text/javascript' src='$filesdir/lightbox.js'></script> ";


//if ($dropShadow)
//   echo "<link rel='stylesheet' type='text/css' href='$filesdir/stylesDrop.css' />";

echo '
<div align="center">
<table summary="A collection of Flickr Photos"><tbody>

';

// Loop through the photos and output the html 
if (count($photos['photo'])>0) // only do it if photos found
foreach ($photos['photo'] as $photo) {
	if ($i % $columns==0)
		echo "<tr>\n";
    /* Find the href */
	if ($photosetsBoolean=="1") {
	    $owner=$photosetOwner;
    } else {
		$owner=$photo[owner];
    }
	$href="https://www.flickr.com/photos/$owner/$photo[id]";
	
	/* Get the photo URL */
	$url=$f->buildPhotoURL($photo, $size);
	$lightboxUrl=$f->buildPhotoURL($photo,$lightboxSize);
	$title=$photo[title];
	if (!$dropShadow)
		echo rwDefaultOutput($href,$url,$title,$showTitles,$lightbox,$lightboxUrl);
	else {
	    echo dropShadowOutput($href,$url,$title,$showTitles,$lightbox,$lightboxUrl);

			$dsTitle.=dropShadowTitle($href,$url,$title,$showTitles,$lightbox,$lightboxUrl);
	}
	$i++;
	// If it reaches the end insert a table end
	if ($i % $columns == 0) {
		echo "</tr>";
		if ($dsTitle!="")
			echo "<tr>$dsTitle</tr>";
		$dsTitle="";

	}
}
else
echo "No Photos Found!";

// Need to finish up the row if it's not an even multiple for drop shadow's
if (($i%$columns != 0) && ($dropShadow==1)) {
  		echo " </tr>";
	if ($dsTitle!="")
		echo "<tr> $dsTitle </tr>" ;
	$dsTitle="";
	
}




echo '</tbody></table></div>';

?>
